Most DLL files in this directory are copyrighted by MAK. They are taken 
from VRForces4.6.1 and intended to be used with a licensed copy of VRForces.

The c2simVRF.exe and c2simVRFd.exe files are compiled versions of open source
code from GMU C4I & Cyber Center.

DLL files with names starting "boost" and "xerces" are compiled versions of
open source code available on the Internet.

