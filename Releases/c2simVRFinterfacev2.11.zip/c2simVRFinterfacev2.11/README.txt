/*----------------------------------------------------------------*
|     Copyright 2020 Networking and Simulation Laboratory         |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for academic purposes is hereby  |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*-----------------------------------------------------------------*/

This directory contains all the code developed by GMU as open source
to provide a prototype C2SIM interface for VT-MAK VR-Forces.
Open source supporting code also is provided.

This version works with VRForces4.7 and VRLink5.4.1 and is 
compiled with Microsoft Visual C++ 15.

The project file provided assumes that VRForces4.7 (including 
toolkit) is installed in C:\MAK\vrforces4.7 and VRLink5.4.1 is 
installed C:\MAK\vrlink4.5.1. These are MAK's default install 
directories. These can be adjusted by changing VrfDir and VrlDir
in the project file c2simVRF.vcxproj.

You must add to your Windows Path Environment Variable:
C:/MAK/vrforces4.7/bin64 and C:/MAK/vrlink5.4.1/bin64

The top-level directory c2simVRFv2.10 can be installed in C:\
or elsewhere. This is changed from v2.6, which had to be located 
the vrforces4.6.1/examples directory. 

v2.10 includes binaries for C++C2SIMClientLibv4.7.0.5, which is 
compatible with C2SIM Reference Implemenation Server v4.7.0 and 
is *not* compatible with earlier versions of the server.

c2simVRFv2.10 accepts a new command line parameter (number 9) that
gives a value in seconds for the interval between Position Reports.
If this parameter has value greater than zero the scripted reports
procedures are ignored and Position Reports (only - no Observation
Reports) are generated at this interval. If this parameter is zero
(the default value) the scripted approach to reports is used. The
scripted approach will work only if VR-Forces4.7 is patched with a 
workaround file vrfLuaDIS.dll to be placed in vrfoces4.7/bin64.

See Install-C2SIM-VRFv2.10 for files to be added to VRForces to
support the scenario used by NATO MSG-145 in CWIX 2019.
