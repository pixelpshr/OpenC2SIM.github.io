-- This script causes the entity to periodically send an observation text message 
-- to its parent. The identity of the parent determined by a text message that is
-- received from the parent. When this message is received, the script begins sending
-- messages.
-- Each message is in the format
-- CONTACTLIST  <count>  <contact 1 name> <class> <lat> <lon> <contact 2 name> <class> ...
-- where count is the number of observations being sent, and
-- class is a class of entity such as "tank", "apc", "aircraft", etc. The mapping from
-- DIS category to vehicle class is given in the landCategory table.

-- Some basic VRF Utilities defined in a common module.
require "vrfutil"

-- Global Variables

local sendInterval = 30

--
-- Global variables get saved when a scenario gets checkpointed in one of the folowing way:
-- 1) If the checkpoint mode is AllGlobals all global variables defined will be saved as part of the save stat
-- 2) In setting CheckpointStateOnly, this means that the script will *only* save variables that are part of the checkpointState table.  If you remove this value, it will then
--    default to the behavior of sabing all globals
--
-- If you wish to change the mode, call setCheckpointMode(AllGlobals) to save all globals or setCheckpointMode(CheckpointStateOnly)
-- to save only those variables in the checkpointState table
-- They get re-initialized when a checkpointed scenario is loaded.
vrf:setCheckpointMode(CheckpointStateOnly)
local s = checkpointState
s.nextSendTime = 0

local landCategory = {"tank",
   "afv",
   "armoredutility",
   "spa",
   "towedarty",
   "wheeledutility",
   "wheeledutility",
   "trackedutility",
   "trackedutility"}


-- Called when the task first starts. Never called again.
function init()
   s.parent = nil
   s.nextSendTime = math.random(15) + vrf:getSimulationTime()
   
   -- Set the tick period for this script.
   vrf:setTickPeriod(2)
end

-- Called each tick while this task is active.
function tick()
   local curTime = vrf:getSimulationTime()
   if this:getForceType() == "Friendly" and
      curTime > s.nextSendTime then
      
      s.nextSendTime = curTime + sendInterval
      
      if s.parent == nil then
         local myType = this:getEntityType()
         
         if vrf:entityTypeMatches(myType, EntityType.PlatformAir()) then
            sendObservations()
         end
         return
      end
      
      -- 
      local contacts = this:getAllHostileContacts()
      reportString = "CONTACTLIST " 
      local count = 0
      local entityString = "" -- All entities: general type and (lat, lon) for each
      for _i, entity in ipairs(contacts) do
         local info = this:getContactInfo(entity)
         if info.detectionLevel >= 2 and
            not entity:isDestroyed() then
            
            local typeInfo
            local contactType = info.entityType
            -- This is an object type, with an extra "n:" prefix, so strip that off.
            local i1, i2
            i1, i2 = string.find(contactType, ":")
            contactType = string.sub(contactType, i2+1, -1)
            
            if vrf:entityTypeMatches(contactType, EntityType.PlatformAir()) then
               typeInfo = "aircraft"
            elseif vrf:entityTypeMatches(contactType,
               EntityType.Lifeform()) then
               typeInfo = "human"
            elseif vrf:entityTypeMatches(contactType,
               EntityType.PlatformSurface()) then
               typeInfo = "ship"
               
            elseif vrf:entityTypeMatches(contactType,
               EntityType.PlatformLand()) then
               
               local category = GetCategory(contactType)
               local catString = landCategory[category]
               if catString ~= nil then 
                  typeInfo = catString
               else
                  typeInfo = "vehicle"
               end
            end
            entityString = entityString .. 
               "\"" .. entity:getName() .. "\"" .. " " ..
               typeInfo
            
            local loc = entity:getLocation3D()
            local lat = math.deg(loc:getLat())
            local lon = math.deg(loc:getLon())
            entityString = entityString ..
               string.format(" %f %f ", lat, lon)
               
            count = count + 1
         end
      end
      if count > 0 then
         reportString = reportString ..
                        string.format("%d ", count) ..
                        entityString
         vrf:sendMessage(s.parent, reportString)
      end
   end
end

function sendObservations()
   local reportString = "OBSERVATION " 
   local contacts = this:getAllHostileContacts()
   local count = 0
   local entityString = "" -- All entities: general type and (lat, lon) for each
   local curTime = vrf:getSimulationTime()
   for _i, entity in ipairs(contacts) do
      
      local info = this:getContactInfo(entity)
      if info.detectionLevel >= 2 and
         not entity:isDestroyed() then
         
         local typeInfo
         local contactType = info.entityType
         -- This is an object type, with an extra "n:" prefix, so strip that off.
         local i1, i2
         i1, i2 = string.find(contactType, ":")
         contactType = string.sub(contactType, i2+1, -1)
         
         if vrf:entityTypeMatches(contactType, EntityType.PlatformAir()) then
            typeInfo = "aircraft"
         elseif vrf:entityTypeMatches(contactType,
            EntityType.Lifeform()) then
            typeInfo = "human"
         elseif vrf:entityTypeMatches(contactType,
            EntityType.PlatformSurface()) then
            typeInfo = "ship"
            
         elseif vrf:entityTypeMatches(contactType,
            EntityType.PlatformLand()) then
            
            local category = GetCategory(contactType)
            local catString = landCategory[category]
            if catString ~= nil then 
               typeInfo = catString
            else
               typeInfo = "vehicle"
            end
         end
         
         entityString = entityString .. 
            typeInfo .. " "
      
         local loc = entity:getLocation3D()
         local lat = math.deg(loc:getLat())
         local lon = math.deg(loc:getLon())
         entityString = entityString ..
            string.format(" %f %f %d  ", 
               lat, lon, curTime)
            
         count = count + 1
      end
   end
   if count > 0 then
      printInfo("Sending OBSERVATION text report")
      
      reportString = reportString ..
                     string.format("\"%s\" ", this:getName()) ..
                     string.format("%d ", count) ..
                     entityString
      vrf:sendReport("text-report", {}, {text = reportString})
   end

end
-- Called immediately before a scenario checkpoint is saved when
-- this task is active.
-- It is typically not necessary to add code to this function.
function saveState()
end

-- Called immediately after a scenario checkpoint is loaded in which
-- this task is active.
-- It is typically not necessary to add code to this function.
function loadState()
end

-- Split the input string into substrings, using the given character as a delimiter.<br/>
-- @param inputString The string to split
-- @param delimiter The single character, or substring, used to split the input. 
-- @return A table containing the substrings of the input string in each entry. The substrings
-- will not include the delimiter character or substring. Leading spaces in each substring 
-- are removed.
function split(inputString, delimiter)
   local out = {}
   -- Add the delimiter to the end to get the tail of the string
   local str = inputString..delimiter
   -- The pattern matches 0 or more spaces, followed by 1 or more non-delimiter
   -- characters, followed by the delimiter. The captured substring is everything
   -- between the leading spaces and the final delimiter.
   local pat = "%s*([^"..delimiter.."]+)"..delimiter
   for ss in string.gmatch(str, pat) do
      table.insert(out, ss)
   end
   return out
end


function receiveTextMessage(message, sender)
   if message == "parent" then
      s.parent = sender
      printVerbose("Send observation: parent is ", s.parent)
   else
      if string.find(message, "parent") then
         printVerbose(string.format("  Rcd \"%s\" ",
            message))
      end
   end
end

------------------------------------------------------------------------------------------------
-- Returns the nth field in the entity type. Generally not used directly, but by other
-- utility functions defined below.
function GetNthField(entityType, n)
   if n < 1 or n > 7 then
      return nil
   end
   
   local i = 1
   for val in string.gmatch(entityType, "%-*%d+") do      
      if i == n then
         return tonumber(val)
      end
      
      i = i + 1
   end
   
   return 0 -- field was not specified in entityType, so must be 0
end
-- Returns the category field from the given entity type
function GetCategory(entityType)
   return GetNthField(entityType, 4)
end
