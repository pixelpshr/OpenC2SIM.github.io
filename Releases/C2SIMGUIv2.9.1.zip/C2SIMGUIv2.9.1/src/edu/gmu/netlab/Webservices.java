/*----------------------------------------------------------------*
|   Copyright 2009-2019 Networking and Simulation Laboratory      |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for all purposes is hereby       |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/

package edu.gmu.netlab;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import javax.swing.JOptionPane;

import sun.misc.Regexp;

import com.jaxfront.core.dom.DOMBuilder;
import com.jaxfront.core.type.Type;
import com.jaxfront.core.util.URLHelper;
import com.jaxfront.core.util.io.cache.XUICache;

import edu.gmu.c4i.c2simclientlib2.*;


/**
 * Web Services Support Methods

 These methods support the C2SIMGUI object
 * 
 * @author	Mohammad Ababneh, C4I Center, George Mason University
 * @since	5/11/2011
 * 
 * @author	Eric Popelka, C4I Center, George Mason University
 * @since	6/29/2011
 */ 
public class Webservices {
    C2SIMGUI bml;
    String root;
    private static final String xmlPreamble = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
  
    /**
     *  constructor
     */
    public Webservices(C2SIMGUI bmlRef)
    {
      bml = bmlRef;
    }
	
    /**
     *   push an XML document string into a C2SIM server 
     */
    public String processBML(
        String xml, 
        String domain,
        String bmlType, 
        String bmlDescription) {

        // Sanitize the input
        Pattern p = Pattern.compile("<\\?\\s*jaxfront\\s*.*?>\r?\n?");
        Matcher m = p.matcher(xml);
        String result = "Error";
        if(m == null) {
            bml.printDebug("Cannot make Matcher in Webservices.processBML");
            return result;
        }
        xml = m.replaceFirst("");
        C2SIMClientREST_Lib restClient = null;
        bml.printDebug("bmlType:" + bmlType);
        if(bmlType.equals("C2SIM"))
            restClient = new C2SIMClientREST_Lib(
                bml.submitterID,
                "server",
                "Report");
        else
            restClient = new C2SIMClientREST_Lib();
        try {          
            restClient.setHost(bml.serverName);
            restClient.setPort("8080");
            restClient.setSubmitter(bml.submitterID);
            restClient.setDomain(domain);
            restClient.setProtocol(bmlType);
        } catch (Exception e1) {
            e1.printStackTrace();
        }

        try {
            bml.printDebug(
                "Starting the bmlRequest Web Service query to:" +
                bml.serverName);

            // call the call SBML method to execute the query
            result = restClient.bmlRequest(xml);
        } catch (Exception e2) {
            bml.showErrorPopup( 
                "Exception in bmlRequest:" + e2.getCause(), 
                bmlDescription);
            e2.printStackTrace();
        }
        bml.printDebug("The bmlRequest query result is : " + result); 
        return result;
        
    }// end processBML()

} // End of Webservices class
