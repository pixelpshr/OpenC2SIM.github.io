The c2simVRF.exe files is compiled version of open source
code from GMU C4I & Cyber Center.

DLL files with names starting "boost" and "xerces" are compiled versions of
open source code available on the Internet.

